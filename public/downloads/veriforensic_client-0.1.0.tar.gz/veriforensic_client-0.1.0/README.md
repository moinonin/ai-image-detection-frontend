# VeriForensic API Client SDK

This package provides a simple, Pythonic wrapper around the VeriForensic public classification APIs. 
It makes it easy to integrate AI image and video classification securely into your workflows without needing to run machine learning models directly on your hardware.

**Features**
- Analyze a single image
- Process batches of images
- Submit videos for frame-by-frame analysis
- Built-in authentication handling using Bearer tokens

## Installation

```bash
pip install veriforensic-client
# Or install locally:
pip install .
```

## Quick Start

### 1. Initialize the Client

```python
from veriforensic import Client

# Initialize the client with your access token
client = Client(
    token="YOUR_BEARER_TOKEN",
    # base_url="https://imageclassifi.fly.dev/api/v1" # (This is the default)
)
```

### 2. Classify a Single Image

```python
result = client.classify_image(
    image_path="suspicious_image.jpg",
    model_type="ml",     # Choices: "ml", "net", "scalpel"
    report_format="json" # Set to "pdf" if you want a PDF document returned instead
)
print(result)
```

### 3. Classify a Batch of Images

```python
batch_results = client.classify_batch(
    image_paths=["image1.png", "image2.jpg"],
    model_type="ml"
)
print("Batch Analysis Complete:", batch_results)
```

### 4. Classify a Video

```python
video_result = client.classify_videos(
    video_paths=["evidence.mp4"],
    partial=True,
    model_type="ml"
)
print("Video Analysis:", video_result)
```
