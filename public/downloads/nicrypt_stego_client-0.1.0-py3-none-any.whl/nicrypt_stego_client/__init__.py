"""
Public import path for the Nicrypt-Stego client SDK.

This is the recommended module name for PyPI users.

Back-compat:
  The original code lives under the `client` package. We keep this wrapper so
  older examples (and internal scripts) can continue to work while new users
  get a predictable import path: `nicrypt_stego_client`.
"""

from client import ClientConfig, NicryptStegoClient, TypedNicryptStegoClient, models

__all__ = ["ClientConfig", "NicryptStegoClient", "TypedNicryptStegoClient", "models"]

