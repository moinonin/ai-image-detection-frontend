from __future__ import annotations

from typing import Dict, List, Optional

from pydantic import BaseModel, Field


class KeyProfile(BaseModel):
    key_id: str
    name: str
    rotation_policy: str
    created_at: str


class KeyCreateResponse(BaseModel):
    request_id: str
    key: KeyProfile


class KeyListResponse(BaseModel):
    request_id: str
    keys: List[KeyProfile]


class KeyRotateResponse(BaseModel):
    request_id: str
    key_id: str
    rotated_at: str
    status: str


class CryptoEncryptResponse(BaseModel):
    request_id: str
    ciphertext: str


class CryptoDecryptResponse(BaseModel):
    request_id: str
    secret: str
    model_hash: Optional[str] = None


class EmbedResponse(BaseModel):
    request_id: str
    stego_text: str
    model_hash: str
    payload_bytes: int
    tokens_used: int


class ExtractResponse(BaseModel):
    request_id: str
    ciphertext: str
    model_hash: str
    confidence: float = Field(ge=0, le=1)


class VerifyResponse(BaseModel):
    request_id: str
    secret: str
    verified: bool
    model_hash: str
    metadata: Dict[str, bool]


class ModelInfo(BaseModel):
    model_name: str
    model_hash: str
    context_length: int
    notes: Optional[str] = None


class ModelListResponse(BaseModel):
    request_id: str
    models: List[ModelInfo]


class ModelPullResponse(BaseModel):
    request_id: str
    status: str
    model_name: str


class ModelStatus(BaseModel):
    model_name: str
    status: str


class ModelStatusResponse(BaseModel):
    request_id: str
    models: List[ModelStatus]


class HealthResponse(BaseModel):
    request_id: str
    status: str
    uptime_s: int


class MetricsResponse(BaseModel):
    request_id: str
    format: str
