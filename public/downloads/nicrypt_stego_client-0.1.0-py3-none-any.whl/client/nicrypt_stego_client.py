from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Dict, Optional

import httpx

from . import models


@dataclass
class ClientConfig:
    # Local dev default. In production you almost always override this.
    base_url: str = "http://127.0.0.1:8125/v1"
    token: Optional[str] = None
    scopes: Optional[str] = None
    timeout_s: float = 30.0


class NicryptStegoClient:
    def __init__(self, config: ClientConfig) -> None:
        self._config = config
        self._client = httpx.Client(timeout=config.timeout_s)

    def close(self) -> None:
        self._client.close()

    def _headers(self) -> Dict[str, str]:
        headers: Dict[str, str] = {}
        if self._config.token:
            headers["Authorization"] = f"Bearer {self._config.token}"
        if self._config.scopes:
            headers["X-Scopes"] = self._config.scopes
        return headers

    def _url(self, path: str) -> str:
        base = self._config.base_url.rstrip("/")
        return f"{base}{path}"

    def create_key(self, name: str, rotation_policy: str = "annual", metadata: Optional[Dict[str, Any]] = None) -> Dict[str, Any]:
        payload = {"name": name, "rotation_policy": rotation_policy, "metadata": metadata or {}}
        resp = self._client.post(self._url("/keys"), json=payload, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def list_keys(self) -> Dict[str, Any]:
        resp = self._client.get(self._url("/keys"), headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def rotate_key(self, key_id: str) -> Dict[str, Any]:
        resp = self._client.post(self._url(f"/keys/{key_id}/rotate"), headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def crypto_encrypt(self, plaintext: str) -> Dict[str, Any]:
        resp = self._client.post(self._url("/crypto/encrypt"), json={"plaintext": plaintext}, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def crypto_decrypt(self, ciphertext: str) -> Dict[str, Any]:
        resp = self._client.post(self._url("/crypto/decrypt"), json={"ciphertext": ciphertext}, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def embed(
        self,
        secret: str,
        cover_prompt: str,
        model_name: Optional[str] = None,
        bits_per_token: int = 3,
        max_new_tokens: int = 200,
        key_id: Optional[str] = None,
        ecc_mode: Optional[str] = None,
        ecc_symbols: Optional[int] = None,
        dry_run: Optional[bool] = None,
        quality_gate: Optional[bool] = None,
        auto_expand: Optional[bool] = None,
        auto_expand_margin: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload = {
            "secret": secret,
            "cover_prompt": cover_prompt,
            "bits_per_token": bits_per_token,
            "max_new_tokens": max_new_tokens,
        }
        if model_name:
            payload["model_name"] = model_name
        if key_id:
            payload["key_id"] = key_id
        if ecc_mode:
            payload["ecc_mode"] = ecc_mode
        if ecc_symbols is not None:
            payload["ecc_symbols"] = ecc_symbols
        if dry_run is not None:
            payload["dry_run"] = dry_run
        if quality_gate is not None:
            payload["quality_gate"] = quality_gate
        if auto_expand is not None:
            payload["auto_expand"] = auto_expand
        if auto_expand_margin is not None:
            payload["auto_expand_margin"] = auto_expand_margin
        resp = self._client.post(self._url("/provenance/embed"), json=payload, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def embed_cipher(
        self,
        ciphertext: str,
        cover_prompt: str,
        model_name: Optional[str] = None,
        bits_per_token: int = 3,
        max_new_tokens: int = 200,
        ecc_mode: Optional[str] = None,
        ecc_symbols: Optional[int] = None,
    ) -> Dict[str, Any]:
        payload = {
            "ciphertext": ciphertext,
            "cover_prompt": cover_prompt,
            "bits_per_token": bits_per_token,
            "max_new_tokens": max_new_tokens,
        }
        if model_name:
            payload["model_name"] = model_name
        if ecc_mode:
            payload["ecc_mode"] = ecc_mode
        if ecc_symbols is not None:
            payload["ecc_symbols"] = ecc_symbols
        resp = self._client.post(self._url("/provenance/embed_cipher"), json=payload, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def extract(
        self,
        stego_text: Optional[str] = None,
        model_name: Optional[str] = None,
        bits_per_token: int = 4,
        ecc_mode: Optional[str] = None,
        ecc_symbols: Optional[int] = None,
        ciphertext: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload = {
            "bits_per_token": bits_per_token,
        }
        if stego_text is not None:
            payload["stego_text"] = stego_text
        if ciphertext is not None:
            payload["ciphertext"] = ciphertext
        if model_name:
            payload["model_name"] = model_name
        if ecc_mode:
            payload["ecc_mode"] = ecc_mode
        if ecc_symbols is not None:
            payload["ecc_symbols"] = ecc_symbols
        resp = self._client.post(self._url("/provenance/extract"), json=payload, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def verify(
        self,
        stego_text: Optional[str] = None,
        model_name: Optional[str] = None,
        bits_per_token: int = 4,
        key_id: Optional[str] = None,
        ecc_mode: Optional[str] = None,
        ecc_symbols: Optional[int] = None,
        ciphertext: Optional[str] = None,
    ) -> Dict[str, Any]:
        payload = {
            "bits_per_token": bits_per_token,
        }
        if stego_text is not None:
            payload["stego_text"] = stego_text
        if ciphertext is not None:
            payload["ciphertext"] = ciphertext
        if model_name:
            payload["model_name"] = model_name
        if key_id:
            payload["key_id"] = key_id
        if ecc_mode:
            payload["ecc_mode"] = ecc_mode
        if ecc_symbols is not None:
            payload["ecc_symbols"] = ecc_symbols
        resp = self._client.post(self._url("/provenance/verify"), json=payload, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def list_models(self) -> Dict[str, Any]:
        resp = self._client.get(self._url("/models"), headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def pull_model(self, model_name: str) -> Dict[str, Any]:
        resp = self._client.post(self._url("/models/pull"), json={"model_name": model_name}, headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def models_status(self) -> Dict[str, Any]:
        resp = self._client.get(self._url("/models/status"), headers=self._headers())
        resp.raise_for_status()
        return resp.json()

    def health(self) -> Dict[str, Any]:
        resp = self._client.get(self._url("/health"))
        resp.raise_for_status()
        return resp.json()

    def metrics(self) -> Dict[str, Any]:
        resp = self._client.get(self._url("/metrics"))
        resp.raise_for_status()
        return resp.json()


class TypedNicryptStegoClient(NicryptStegoClient):
    def create_key(self, name: str, rotation_policy: str = "annual", metadata: Optional[Dict[str, Any]] = None) -> models.KeyCreateResponse:
        return models.KeyCreateResponse.model_validate(super().create_key(name, rotation_policy, metadata))

    def list_keys(self) -> models.KeyListResponse:
        return models.KeyListResponse.model_validate(super().list_keys())

    def rotate_key(self, key_id: str) -> models.KeyRotateResponse:
        return models.KeyRotateResponse.model_validate(super().rotate_key(key_id))

    def crypto_encrypt(self, plaintext: str) -> models.CryptoEncryptResponse:
        return models.CryptoEncryptResponse.model_validate(super().crypto_encrypt(plaintext))

    def crypto_decrypt(self, ciphertext: str) -> models.CryptoDecryptResponse:
        return models.CryptoDecryptResponse.model_validate(super().crypto_decrypt(ciphertext))

    def embed(
        self,
        secret: str,
        cover_prompt: str,
        model_name: Optional[str] = None,
        bits_per_token: int = 3,
        max_new_tokens: int = 200,
        key_id: Optional[str] = None,
        ecc_mode: Optional[str] = None,
        ecc_symbols: Optional[int] = None,
        dry_run: Optional[bool] = None,
        quality_gate: Optional[bool] = None,
        auto_expand: Optional[bool] = None,
        auto_expand_margin: Optional[int] = None,
    ) -> models.EmbedResponse:
        return models.EmbedResponse.model_validate(
            super().embed(
                secret,
                cover_prompt,
                model_name,
                bits_per_token,
                max_new_tokens,
                key_id,
                ecc_mode,
                ecc_symbols,
                dry_run,
                quality_gate,
                auto_expand,
                auto_expand_margin,
            )
        )

    def embed_cipher(
        self,
        ciphertext: str,
        cover_prompt: str,
        model_name: Optional[str] = None,
        bits_per_token: int = 3,
        max_new_tokens: int = 200,
        ecc_mode: Optional[str] = None,
        ecc_symbols: Optional[int] = None,
    ) -> models.EmbedResponse:
        return models.EmbedResponse.model_validate(
            super().embed_cipher(ciphertext, cover_prompt, model_name, bits_per_token, max_new_tokens, ecc_mode, ecc_symbols)
        )

    def extract(
        self,
        stego_text: Optional[str] = None,
        model_name: Optional[str] = None,
        bits_per_token: int = 4,
        ecc_mode: Optional[str] = None,
        ecc_symbols: Optional[int] = None,
        ciphertext: Optional[str] = None,
    ) -> models.ExtractResponse:
        return models.ExtractResponse.model_validate(
            super().extract(stego_text, model_name, bits_per_token, ecc_mode, ecc_symbols, ciphertext)
        )

    def verify(
        self,
        stego_text: Optional[str] = None,
        model_name: Optional[str] = None,
        bits_per_token: int = 4,
        key_id: Optional[str] = None,
        ecc_mode: Optional[str] = None,
        ecc_symbols: Optional[int] = None,
        ciphertext: Optional[str] = None,
    ) -> models.VerifyResponse:
        return models.VerifyResponse.model_validate(
            super().verify(stego_text, model_name, bits_per_token, key_id, ecc_mode, ecc_symbols, ciphertext)
        )

    def list_models(self) -> models.ModelListResponse:
        return models.ModelListResponse.model_validate(super().list_models())

    def pull_model(self, model_name: str) -> models.ModelPullResponse:
        return models.ModelPullResponse.model_validate(super().pull_model(model_name))

    def models_status(self) -> models.ModelStatusResponse:
        return models.ModelStatusResponse.model_validate(super().models_status())

    def health(self) -> models.HealthResponse:
        return models.HealthResponse.model_validate(super().health())

    def metrics(self) -> models.MetricsResponse:
        return models.MetricsResponse.model_validate(super().metrics())
