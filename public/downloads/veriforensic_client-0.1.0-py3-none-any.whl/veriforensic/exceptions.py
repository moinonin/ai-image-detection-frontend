class VeriForensicError(Exception):
    """Base exception for all VeriForensic client errors."""
    pass

class APIError(VeriForensicError):
    """Raised when the API returns an error response."""
    def __init__(self, message: str, status_code: int = None, details: dict = None):
        super().__init__(message)
        self.status_code = status_code
        self.details = details

class ValidationError(VeriForensicError):
    """Raised when request validation fails before sending."""
    pass
