import os
import requests
from typing import List, Optional, Union, Dict, Any
from pathlib import Path

from .exceptions import APIError, ValidationError

class Client:
    """VeriForensic API Client for Image and Video Classification."""
    
    def __init__(self, token: str, base_url: str = "https://imageclassifi.fly.dev/api/v1"):
        """
        Initialize the public-facing API client.
        
        Args:
            token: Bearer token for authentication.
            base_url: The base URL of the API.
        """
        self.token = token
        self.base_url = base_url.rstrip("/")
        self.session = requests.Session()
        self.session.headers.update({
            "Authorization": f"Bearer {self.token}"
        })

    def _handle_response(self, response: requests.Response) -> Union[Dict[str, Any], bytes]:
        if not response.ok:
            error_details = {}
            try:
                error_details = response.json()
            except ValueError:
                error_details = {"detail": response.text}
            raise APIError(
                message=f"API request failed: {response.status_code}",
                status_code=response.status_code,
                details=error_details
            )
            
        # Return raw bytes if it's a PDF
        if response.headers.get("content-type") == "application/pdf":
            return response.content
            
        return response.json()

    def classify_image(
        self, 
        image_path: Union[str, Path], 
        model_type: str = "ml", 
        report_format: str = "json",
        use_cache: bool = True
    ) -> Union[Dict[str, Any], bytes]:
        """
        Classify a single image via the API.
        
        Args:
            image_path: Path to the local image file.
            model_type: "ml", "net", or "scalpel". Defaults to "ml".
            report_format: "json" or "pdf".
            use_cache: Whether to return cached results if available.
        """
        path = Path(image_path)
        if not path.exists():
            raise ValidationError(f"Image not found at path: {image_path}")

        url = f"{self.base_url}/classify/single"
        
        data = {
            "model_type": model_type,
            "report_format": report_format,
            "use_cache": str(use_cache).lower()
        }
        
        with open(path, "rb") as f:
            files = {"file": (path.name, f, "image/jpeg")}
            response = self.session.post(url, data=data, files=files)
            
        return self._handle_response(response)

    def classify_batch(
        self, 
        image_paths: List[Union[str, Path]], 
        model_type: str = "ml", 
        report_format: str = "json",
        use_cache: bool = True
    ) -> Union[Dict[str, Any], bytes]:
        """Classify a batch of images via the API."""
        if not image_paths:
            raise ValidationError("At least one image path must be provided.")

        url = f"{self.base_url}/classify/batch"
        data = {
            "model": model_type,
            "report_format": report_format,
            "use_cache": str(use_cache).lower()
        }
        
        files_payload = []
        opened_files = []
        try:
            for p in image_paths:
                path = Path(p)
                if not path.exists():
                    raise ValidationError(f"Image not found at path: {p}")
                f = open(path, "rb")
                opened_files.append(f)
                files_payload.append(("files", (path.name, f, "image/jpeg")))

            response = self.session.post(url, data=data, files=files_payload)
            return self._handle_response(response)
        finally:
            for f in opened_files:
                f.close()

    def classify_videos(
        self, 
        video_paths: List[Union[str, Path]], 
        partial: bool = True,
        model_type: str = "ml", 
        report_format: str = "json",
        use_cache: bool = True
    ) -> Union[Dict[str, Any], bytes]:
        """Classify videos via the API."""
        if not video_paths:
            raise ValidationError("At least one video path must be provided.")

        url = f"{self.base_url}/classify/videos"
        data = {
            "partial": str(partial).lower(),
            "model": model_type,
            "report_format": report_format,
            "use_cache": str(use_cache).lower()
        }
        
        files_payload = []
        opened_files = []
        try:
            for p in video_paths:
                path = Path(p)
                if not path.exists():
                    raise ValidationError(f"Video not found at path: {p}")
                f = open(path, "rb")
                opened_files.append(f)
                files_payload.append(("files", (path.name, f, "video/mp4")))

            response = self.session.post(url, data=data, files=files_payload)
            return self._handle_response(response)
        finally:
            for f in opened_files:
                f.close()
