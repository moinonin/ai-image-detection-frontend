# Nicrypt-Stego Client SDK

This package provides the typed HTTP client for the Nicrypt-Stego API.

- API reference: `docs/API_SPEC.md`
- Quickstart: `docs/quickstart.md`

## Install

```bash
pip install nicrypt-stego-client
```

## Smoke Test (Manual)

1. Start the API (in one terminal):

```bash
. .venv/bin/activate
PYTHONPATH=apps/api JWT_SECRET=dev-secret uvicorn server.app:app --reload --port 8125
```

2. Run this client snippet (in another terminal):

```bash
. .venv/bin/activate
python - <<'PY'
from nicrypt_stego_client import ClientConfig, NicryptStegoClient

cfg = ClientConfig(
    base_url="http://127.0.0.1:8125/v1",
    token=None,  # set a JWT here if your API requires auth
)
c = NicryptStegoClient(cfg)

print("health:", c.health())

resp = c.embed(
    secret="you@example.com|2026-02-15|Client SDK smoke",
    cover_prompt="Subject: Test\\n\\nHello team,\\nThis is a test email.\\n",
    model_name="sshleifer/tiny-gpt2",
    bits_per_token=3,
    max_new_tokens=220,
    quality_gate=False,
)
print("embed keys:", sorted(resp.keys()))
print("ciphertext present:", "ciphertext" in resp and bool(resp["ciphertext"]))

v = c.verify(
    ciphertext=resp["ciphertext"],
    model_name="sshleifer/tiny-gpt2",
    bits_per_token=4,
)
print("verify:", v)

c.close()
PY
```

Notes:
- This uses `NicryptStegoClient` (untyped dict responses) because the API surface evolves quickly.
- `TypedNicryptStegoClient` uses Pydantic models in `packages/client/client/models.py`, so if the API adds new response fields (e.g. `ciphertext`) those fields may be dropped until the models are updated.

Back-compat:
- Older code samples may use `from client import ...`. That import path is still supported, but `nicrypt_stego_client` is the recommended public module name for PyPI users.
