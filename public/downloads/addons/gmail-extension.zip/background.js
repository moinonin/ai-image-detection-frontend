chrome.runtime.onMessage.addListener((message, _sender, sendResponse) => {
  if (message?.type !== "ns-verify" && message?.type !== "ns-embed") {
    return;
  }

  // Web Store build: API base URL is user-configured, so we request runtime host permissions.
  // If permission was not granted, fail fast with a clear error.
  try {
    const u = new URL(message.url);
    const originPattern = `${u.origin}/*`;
    if (chrome?.permissions?.contains) {
      chrome.permissions.contains({ origins: [originPattern] }, (has) => {
        if (!has) {
          sendResponse({
            ok: false,
            status: 0,
            error: `Missing permission for ${u.origin}. Open extension options and allow access.`,
          });
          return;
        }
        doFetch();
      });
      return true;
    }
  } catch {
    // ignore; fall through to fetch which will return a clearer error
  }

  function doFetch() {
  fetch(message.url, {
    method: "POST",
    headers: message.headers,
    body: message.body,
  })
    .then(async (resp) => {
      // Read as text first so we can return something meaningful even if JSON parsing fails.
      let text = "";
      try {
        text = await resp.text();
      } catch {
        text = "";
      }
      let data = null;
      try {
        data = text ? JSON.parse(text) : null;
      } catch {
        data = null;
      }
      sendResponse({ ok: resp.ok, status: resp.status, data, text });
    })
    .catch((err) => {
      sendResponse({ ok: false, error: String(err) });
    });
  }

  return true;
});
