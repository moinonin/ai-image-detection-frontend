const PANEL_ID = "ns-verify-panel";
const EMBED_ID = "ns-embed-button";
const BADGE_ID = "ns-verify-badge";
const COMPOSE_STATUS_ID = "ns-compose-status";
let lastPanelState = null;
// Bump this whenever we need to confirm the loaded content script version in the Gmail page.
const NS_BUILD_ID = "2026-02-22-gmail-siglink-3";

function getSettings() {
  return new Promise((resolve) => {
    chrome.storage.sync.get(
      {
        baseUrl: "",
        token: "",
        modelName: "sshleifer/tiny-gpt2",
        bitsPerToken: 4,
        enableLegacyEmbed: false,
        signatureEmbed: true,
        signatureNote: "Best regards",
        senderOverride: "",
        autoSign: true,
      },
      resolve
    );
  });
}

function setPanel(text, detail = "", ok = false) {
  const panel = document.getElementById(PANEL_ID);
  if (!panel) return;
  panel.classList.add("visible");
  const status = panel.querySelector(".ns-verify-status");
  status.textContent = text;
  status.style.color = ok ? "#16a34a" : "#dc2626";
  const detailNode = panel.querySelector(".ns-verify-detail");
  detailNode.textContent = detail || "";
  lastPanelState = { text, detail: detail || "", ok: !!ok };
  const badge = document.getElementById(BADGE_ID);
  if (badge) badge.textContent = "Obscure";
}

function showLastPanel() {
  if (!lastPanelState) return false;
  setPanel(lastPanelState.text, lastPanelState.detail, lastPanelState.ok);
  return true;
}

function setBadge(text, state = "pending") {
  const badge = document.getElementById(BADGE_ID);
  if (!badge) return;
  badge.textContent = text;
  badge.classList.remove("verified", "unverified", "partial");
  if (state === "verified") {
    badge.classList.add("verified");
  }
  if (state === "unverified") {
    badge.classList.add("unverified");
  }
  if (state === "partial") {
    badge.classList.add("partial");
  }
}

function setComposeStatus(text, state = "pending") {
  const pill = document.getElementById(COMPOSE_STATUS_ID);
  if (!pill) return;
  pill.textContent = text;
  pill.classList.remove("verified", "unverified");
  if (state === "verified") {
    pill.classList.add("verified");
  }
  if (state === "unverified") {
    pill.classList.add("unverified");
  }
  pill.classList.add("visible");
  clearTimeout(pill._hideTimer);
  pill._hideTimer = setTimeout(() => {
    pill.classList.remove("visible");
  }, 4000);
}

function getLastCiphertext() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({ lastCiphertext: "", lastBpt: 4 }, resolve);
  });
}

function setLastCiphertext(ciphertext, bpt) {
  chrome.storage.sync.set({ lastCiphertext: ciphertext, lastBpt: bpt });
}

function extractEmailBody({ allowSelection = true } = {}) {
  const selection = allowSelection && window.getSelection && window.getSelection().toString().trim();
  // Selection is extremely error-prone for verification because users often highlight only part of a long
  // token line (or just the visible badge), which makes parsing fail deterministically. So we only use the
  // selection when it clearly contains our provenance markers.
  if (
    selection &&
    selection.length > 20 &&
    (selection.includes("NS-") || selection.includes("[Provenance:") || selection.includes("NS-SIG-LINK:") || selection.includes("ns_sig="))
  ) {
    return { text: selection, html: "", bpt: null, selectionUsed: true };
  }

  const bodies = Array.from(document.querySelectorAll("div.a3s"));
  if (bodies.length) {
    const pruneQuotes = (node) => {
      const looksLikeMarkerText = (t) =>
        (t || "").includes("NS-") ||
        (t || "").includes("[Provenance:") ||
        (t || "").includes("ns-stego verified") ||
        (t || "").includes("NS-SIG-LINK:") ||
        (t || "").includes("ns_sig=");
      const looksLikeMarkerNode = (n) => {
        try {
          const t = (n.innerText || n.textContent || "").trim();
          if (looksLikeMarkerText(t)) return true;
          // Some of our machine markers are intentionally "invisible" (font-size:0 / transparent).
          // Gmail can wrap these in `.gmail_extra` where `innerText` may omit them, but the HTML/link
          // carrier still survives. If we prune this subtree, verification becomes impossible.
          const html = (n.innerHTML || "").toLowerCase();
          if (
            html.includes("ns-sig-link") ||
            html.includes("ns-attb64") ||
            html.includes("ns-attachments") ||
            html.includes("ns_sig=") ||
            html.includes("data-provenance")
          ) {
            return true;
          }
          const links = Array.from(n.querySelectorAll("a[href]"));
          for (const a of links) {
            const href = a.getAttribute("href") || a.href || "";
            if (!href) continue;
            if (href.includes("ns_sig=") || href.includes("ns-sig=") || href.includes("ns_sig%3d")) return true;
            if (href.includes("www.google.com/url") && (href.includes("ns_sig") || href.includes("ns-sig"))) return true;
          }
        } catch (err) {
          // ignore and fall through
        }
        return false;
      };
      // Gmail often wraps "extra"/trimmed content in these containers. We remove them to avoid accidentally
      // verifying quoted messages, but must keep them if they contain our markers.
      node.querySelectorAll(".gmail_quote, blockquote, .gmail_extra").forEach((n) => {
        if (!looksLikeMarkerNode(n)) n.remove();
      });
    };
    // Prefer the most recent body that actually contains our markers.
    for (let i = bodies.length - 1; i >= 0; i--) {
      const node = bodies[i];
      const clone = node.cloneNode(true);
      pruneQuotes(clone);
      const text = (clone.innerText || "").trim();
      if (!text) continue;
      // Prefer the body that contains our signature carrier explicitly.
      if (text.includes("NS-SIG-LINK:") || text.includes("ns_sig=")) {
        return { text, html: clone.innerHTML || "", bpt: null, selectionUsed: false };
      }
      if (text.includes("NS-") || text.includes("[Provenance:") || text.includes("Provenance")) {
        return { text, html: clone.innerHTML || "", bpt: null, selectionUsed: false };
      }
    }
    for (let i = bodies.length - 1; i >= 0; i--) {
      const node = bodies[i];
      const clone = node.cloneNode(true);
      pruneQuotes(clone);
      const text = (clone.innerText || "").trim();
      if (text) return { text, html: clone.innerHTML || "", bpt: null, selectionUsed: false };
    }
  }

  const candidates = Array.from(document.querySelectorAll('[aria-label="Message Body"], div[role="listitem"]'));
  let best = "";
  let bestLooksLikeProvenance = false;
  for (const node of candidates) {
    const text = (node.innerText || "").trim();
    if (!text) continue;
    const looksLikeProvenance = text.includes("NS-") || text.includes("[Provenance:") || text.includes("Provenance");
    if (looksLikeProvenance && !bestLooksLikeProvenance) {
      best = text;
      bestLooksLikeProvenance = true;
      continue;
    }
    if (looksLikeProvenance === bestLooksLikeProvenance && text.length > best.length) {
      best = text;
    }
  }
  return { text: best, html: "", bpt: null, selectionUsed: false };
}

function updateBadgeFromStamp() {
  const extracted = extractEmailBody({ allowSelection: false });
  const parsed = extractProvenanceBlock(extracted.text, extracted.html);
  if (parsed.status) {
    const label = parsed.status === "verified" ? "Verified" : "Unverified";
    setBadge(label, parsed.status === "verified" ? "verified" : "unverified");
  }
}

function extractProvenanceBlock(rawText, rawHtml = "") {
  const raw = rawText || "";
  const html = rawHtml || "";
  if (!raw && !html) {
    return {
      text: "",
      bpt: null,
      found: false,
      cipher: "",
      ts: "",
      status: "",
      reason: "",
      attachments: "",
      attachmentsB64: "",
    };
  }
  const start = raw.indexOf("NS-PROVENANCE-START");
  const end = raw.indexOf("NS-PROVENANCE-END");
  let bpt = null;
  const bptMatch = raw.match(/NS-BPT:\s*(\d+)/);
  if (bptMatch) {
    bpt = Number(bptMatch[1]);
  }
  const cipherMatch = raw.match(/NS-CIPHERTEXT:\s*([A-Za-z0-9_=-]+)/);
  const tsMatch = raw.match(/NS-TIMESTAMP:([^\n]+)/);
  const extractFoldedMarker = (text, marker) => {
    const idx = (text || "").indexOf(marker);
    if (idx === -1) return "";
    const tail = text.slice(idx).split("\n");
    // We slice starting at the marker, so the first line always begins with it.
    const first = tail[0].slice(marker.length).trim();
    let combined = first;
    for (let i = 1; i < tail.length; i++) {
      const line = tail[i];
      if (!line) break;
      const trimmed = line.trim();
      if (!trimmed) break;
      if (/^NS-[A-Z0-9_-]+:/i.test(trimmed) || /^\[Provenance:/i.test(trimmed)) break;
      // Continuation fragments can be very short if the client visually wraps long strings.
      if (!/^[A-Za-z0-9_=-]{1,}$/.test(trimmed)) break;
      combined += trimmed;
    }
    return combined.replace(/\s+/g, "");
  };

  const attachmentsToken = extractFoldedMarker(raw, "NS-ATTACHMENTS:");
  const extractAttb64 = (text) => {
    const idx = (text || "").indexOf("NS-ATTB64:");
    if (idx === -1) return "";
    const tail = text.slice(idx).split("\n");
    const first = tail[0].replace(/^NS-ATTB64:\s*/i, "").trim();
    let combined = first;
    for (let i = 1; i < tail.length; i++) {
      const line = tail[i];
      if (!line) break;
      // Email clients frequently hard-wrap long lines without leading whitespace. Accept either:
      // - RFC-style folded lines starting with whitespace
      // - raw base64-ish continuation lines
      //
      // Stop when the next marker or non-token content begins.
      const trimmed = line.trim();
      if (!trimmed) break;
      if (/^NS-[A-Z0-9_-]+:/i.test(trimmed) || /^\[Provenance:/i.test(trimmed)) break;
      // Standard base64 can include '+' and '/'.
      // Continuation fragments can be very short if the client visually wraps long strings.
      if (!/^[A-Za-z0-9+/=_-]{1,}$/.test(trimmed)) break;
      combined += trimmed;
    }
    return combined.replace(/\s+/g, "");
  };
  let attachmentsB64FromText = extractAttb64(raw);
  if (!attachmentsB64FromText && html && html.includes("NS-ATTB64:")) {
    const htmlText = html
      .replace(/<br\s*\/?>/gi, "\n")
      .replace(/<[^>]+>/g, " ");
    attachmentsB64FromText = extractAttb64(htmlText);
  }
  const cipher = cipherMatch ? cipherMatch[1].trim() : "";
  const ts = tsMatch ? tsMatch[1].trim() : "";
  if (!cipher && html.includes("NS-CIPHERTEXT:")) {
    const htmlCipher = html.match(/NS-CIPHERTEXT:([A-Za-z0-9_=-]+)/);
    const htmlTs = html.match(/NS-TIMESTAMP:([^<]+)/);
    if (htmlCipher) {
      return {
        text: raw.trim(),
        bpt,
        found: true,
        cipher: htmlCipher[1].trim(),
        ts: htmlTs ? htmlTs[1].trim() : "",
        status: "",
      };
    }
  }
  if (html.includes("data-provenance")) {
    let statusValue = "";
    let reasonValue = "";
    let attachmentsValue = "";
    let attachmentsB64Value = "";
    try {
      const wrapper = document.createElement("div");
      wrapper.innerHTML = html;
      const badge = wrapper.querySelector("[data-provenance]");
      if (badge) {
        statusValue = badge.getAttribute("data-provenance") || "";
        reasonValue = badge.getAttribute("data-provenance-reason") || "";
        attachmentsValue = badge.getAttribute("data-provenance-attachments") || "";
        attachmentsB64Value = badge.getAttribute("data-provenance-attachments-b64") || "";
      }
      // If huge data-* attributes were stripped/truncated, fall back to hidden marker text
      // included inside the badge element.
      if (!attachmentsB64Value) {
        const inner = (wrapper.innerText || "").trim();
        attachmentsB64Value = extractAttb64(inner);
      }
    } catch (err) {
      console.warn("[Nicrypt-Stego] Failed to parse provenance attributes", err);
    }
    return {
      text: raw.trim(),
      bpt,
      found: false,
      cipher: "",
      ts: "",
      status: statusValue,
      reason: reasonValue,
      attachments: attachmentsValue,
      attachmentsB64: attachmentsB64Value || attachmentsB64FromText,
    };
  }
  if (start !== -1 && end !== -1 && end > start) {
    const block = raw.slice(start + "NS-PROVENANCE-START".length, end).trim();
    return { text: block, bpt, found: true, cipher, ts, attachments: attachmentsToken };
  }
  return {
    text: raw.trim(),
    bpt,
    found: false,
    cipher,
    ts,
    status: "",
    reason: "",
    attachments: attachmentsToken,
    attachmentsB64: attachmentsB64FromText,
  };
}

function extractSignatureToken(rawText, rawHtml = "") {
  const raw = rawText || "";
  const html = rawHtml || "";
  const normalizeToken = (token) => {
    if (!token) return "";
    // Gmail can insert weird Unicode / soft wraps; keep only the token alphabet.
    return String(token)
      // Normalize common Unicode hyphens/minus to ASCII '-' (base64url uses '-' / '_').
      .replace(/[‐‑‒–—―−﹣－]/g, "-")
      .replace(/[＿﹍]/g, "_")
      .replace(/\s+/g, "")
      // Signature tokens are base64url without padding; strip any stray QP artifacts.
      .replace(/=/g, "")
      // Tokens use base64url-ish chars plus '.' separators: [A-Za-z0-9._-=]
      // Keep '+' and '/' too since some contexts may use standard base64.
      .replace(/[^A-Za-z0-9_.+\\/\\-_]/g, "");
  };

  // Quick regex extraction (most robust): pull token directly from any `ns_sig=...` marker.
  const extractDirectNsSig = (text) => {
    const s = String(text || "");
    // IMPORTANT: be strict about the token shape so we don't accidentally "blend" a truncated token
    // with adjacent Gmail UI text and produce an invalid signature candidate.
    const m = s.match(/(?:^|[^A-Za-z0-9_=-])(ns_sig|ns-sig)=((?:v1c|v1)\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43})/i);
    return m ? m[2] : "";
  };

  const extractFromSigLinkText = (text) => {
    const raw = String(text || "");
    const idx = raw.toUpperCase().indexOf("NS-SIG-LINK:");
    if (idx === -1) return "";
    const after = raw.slice(idx + "NS-SIG-LINK:".length);
    const lines = after.split("\n");
    const first = (lines[0] || "").trim();
    if (!first) return "";
    let combined = first;
    for (let i = 1; i < lines.length; i++) {
      const trimmed = (lines[i] || "").trim();
      if (!trimmed) break;
      if (/^NS-[A-Z0-9_-]+:/i.test(trimmed) || /^\[Provenance:/i.test(trimmed)) break;
      // Allow wrapped URLs / query strings.
      if (!/^[A-Za-z0-9_.+\\/?:&=%#-]{1,}$/.test(trimmed)) break;
      combined += trimmed;
    }
    return combined.replace(/\s+/g, "");
  };

  const extractNsSigFromHref = (href) => {
    if (!href) return "";
    const s = String(href);
    // 0) The marker may only include a query-string or the token itself.
    const qs = s.match(/(?:^|[?#&])(ns_sig|ns-sig)=([^&#\\s]+)/i);
    if (qs) return qs[2] || "";
    const directToken = s.match(/^(v1c|v1)\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]{43}$/);
    if (directToken) return s;
    const safeDecode = (s) => {
      try {
        return decodeURIComponent(s);
      } catch (err) {
        return s;
      }
    };
    const toUrl = (s) => {
      try {
        return new URL(s);
      } catch (err) {
        try {
          return new URL(s, window.location.href);
        } catch (err2) {
          return null;
        }
      }
    };
    const nsSigFromUrl = (u) => {
      try {
        const url = typeof u === "string" ? toUrl(u) : u;
        if (!url) return "";
        return url.searchParams.get("ns_sig") || url.searchParams.get("ns-sig") || "";
      } catch (err) {
        return "";
      }
    };

    // 1) Direct link to the sender domain.
    const direct = nsSigFromUrl(href);
    if (direct) return direct;

    // 2) Gmail/Google safe redirect wrapper (common in Gmail web UI).
    const u = toUrl(href);
    if (!u) return "";
    if (u.hostname !== "www.google.com" || u.pathname !== "/url") return "";
    const wrapped = u.searchParams.get("q") || u.searchParams.get("url") || "";
    if (!wrapped) return "";
    let candidate = wrapped;
    for (let i = 0; i < 3; i++) {
      const decoded = safeDecode(candidate);
      if (decoded === candidate) break;
      candidate = decoded;
    }
    return nsSigFromUrl(candidate);
  };

  const extractFromText = (text) => {
    let idx = text.indexOf("NS-SIGNATURE:");
    let prefix = "NS-SIGNATURE:";
    if (idx === -1) {
      idx = text.indexOf("NS-SIG:");
      prefix = "NS-SIG:";
    }
    if (idx === -1) return "";
    const after = text.slice(idx + prefix.length);
    const lines = after.split("\n");
    const first = (lines[0] || "").trim();
    if (!first) return "";
    // Support folded markers (continuation lines) without accidentally gluing the next marker
    // (e.g. "NS-ATTB64:") onto the end of the signature token.
    let combined = first;
    for (let i = 1; i < lines.length; i++) {
      const trimmed = (lines[i] || "").trim();
      if (!trimmed) break;
      if (/^NS-[A-Z0-9_-]+:/i.test(trimmed) || /^\[Provenance:/i.test(trimmed)) break;
      // Continuation fragments can be very short if the client visually wraps long strings.
      if (!/^[A-Za-z0-9_.+\/\\_-]{1,}$/.test(trimmed)) break;
      combined += trimmed;
    }
    const token = normalizeToken(combined);
    const match = token.match(/^([A-Za-z0-9_.+\/\\-_]+)/);
    return match ? match[1] : "";
  };

  // 0) Explicit NS-SIG-LINK marker (most stable across clients).
  const direct = extractDirectNsSig(raw) || extractDirectNsSig(html);
  if (direct) return normalizeToken(direct);

  const linkToken = extractNsSigFromHref(extractFromSigLinkText(raw));
  if (linkToken) return normalizeToken(linkToken);

  // Prefer visible text first. Some Gmail renders strip/truncate long `data-*` attributes.
  const rawToken = extractFromText(raw);
  if (rawToken) return rawToken;

  if (html) {
    const linkFromHtmlText = extractNsSigFromHref(extractFromSigLinkText(html.replace(/<[^>]+>/g, " ")));
    if (linkFromHtmlText) return normalizeToken(linkFromHtmlText);
    const dataMatch = html.match(/data-ns-signature=["']([^"']+)["']/);
    if (dataMatch) return normalizeToken(dataMatch[1]);
    const htmlText = html.replace(/<[^>]+>/g, " ");
    const tokenFromHtmlText = extractFromText(htmlText);
    if (tokenFromHtmlText) return tokenFromHtmlText;
  }

  // DOM attribute fallback (last resort)
  try {
    const el = document.querySelector("div.a3s [data-ns-signature]") || document.querySelector("[data-ns-signature]");
    if (el) {
      const v = normalizeToken(el.getAttribute("data-ns-signature") || "");
      if (v) return v;
    }
  } catch (err) {
    // ignore
  }

  // href-carried token fallback (Gmail strips many data-* attributes).
  try {
    const bodies = Array.from(document.querySelectorAll("div.a3s"));
    for (let i = bodies.length - 1; i >= 0; i--) {
      const links = Array.from(bodies[i].querySelectorAll("a[href]"));
      for (const a of links) {
        const href = a.getAttribute("href") || a.href || "";
        const t = extractNsSigFromHref(href);
        if (t) return normalizeToken(t);
      }
    }
  } catch (err) {
    // ignore
  }
  return "";
}

function collectSignatureCandidates(rawText, rawHtml = "") {
  const raw = rawText || "";
  const html = rawHtml || "";
  const normalizeToken = (token) => {
    if (!token) return "";
    return String(token)
      .replace(/[‐‑‒–—―−﹣－]/g, "-")
      .replace(/[＿﹍]/g, "_")
      .replace(/\s+/g, "")
      .replace(/=/g, "")
      .replace(/[^A-Za-z0-9_.+\\/\\-_]/g, "");
  };

  const extractFromSigLinkText = (text) => {
    const raw = String(text || "");
    const idx = raw.toUpperCase().indexOf("NS-SIG-LINK:");
    if (idx === -1) return "";
    const after = raw.slice(idx + "NS-SIG-LINK:".length);
    const lines = after.split("\n");
    const first = (lines[0] || "").trim();
    if (!first) return "";
    let combined = first;
    for (let i = 1; i < lines.length; i++) {
      const trimmed = (lines[i] || "").trim();
      if (!trimmed) break;
      if (/^NS-[A-Z0-9_-]+:/i.test(trimmed) || /^\[Provenance:/i.test(trimmed)) break;
      if (!/^[A-Za-z0-9_.+\\/?:&=%#-]{1,}$/.test(trimmed)) break;
      combined += trimmed;
    }
    return combined.replace(/\\s+/g, "");
  };

  const out = [];
  const seen = new Set();
  const looksLikeSigToken = (token) => /^(v1c|v1)\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43}$/.test(token || "");
  const push = (t) => {
    const v = normalizeToken(t);
    if (!v) return;
    if (!looksLikeSigToken(v)) return;
    if (seen.has(v)) return;
    seen.add(v);
    out.push(v);
  };

  const extractNsSigFromHref = (href) => {
    if (!href) return "";
    const s = String(href);
    const qs = s.match(/(?:^|[?#&])(ns_sig|ns-sig)=([^&#\\s]+)/i);
    if (qs) return qs[2] || "";
    const directToken = s.match(/^(v1c|v1)\\.[A-Za-z0-9_-]+\\.[A-Za-z0-9_-]{43}$/);
    if (directToken) return s;
    const safeDecode = (s) => {
      try {
        return decodeURIComponent(s);
      } catch (err) {
        return s;
      }
    };
    const toUrl = (s) => {
      try {
        return new URL(s);
      } catch (err) {
        try {
          return new URL(s, window.location.href);
        } catch (err2) {
          return null;
        }
      }
    };
    const nsSigFromUrl = (u) => {
      try {
        const url = typeof u === "string" ? toUrl(u) : u;
        if (!url) return "";
        return url.searchParams.get("ns_sig") || url.searchParams.get("ns-sig") || "";
      } catch (err) {
        return "";
      }
    };

    const direct = nsSigFromUrl(href);
    if (direct) return direct;

    const u = toUrl(href);
    if (!u) return "";
    if (u.hostname !== "www.google.com" || u.pathname !== "/url") return "";
    const wrapped = u.searchParams.get("q") || u.searchParams.get("url") || "";
    if (!wrapped) return "";
    let candidate = wrapped;
    for (let i = 0; i < 3; i++) {
      const decoded = safeDecode(candidate);
      if (decoded === candidate) break;
      candidate = decoded;
    }
    return nsSigFromUrl(candidate);
  };

  // -2) Explicit NS-SIG-LINK marker.
  push(extractNsSigFromHref(extractFromSigLinkText(raw)));
  if (html) push(extractNsSigFromHref(extractFromSigLinkText(html.replace(/<[^>]+>/g, " "))));

  // -1) href-carried token (most reliable in Gmail; survives DOM sanitization).
  try {
    const bodies = Array.from(document.querySelectorAll("div.a3s"));
    for (let i = bodies.length - 1; i >= 0; i--) {
      const links = Array.from(bodies[i].querySelectorAll("a[href]"));
      for (const a of links) {
        const href = a.getAttribute("href") || a.href || "";
        const t = extractNsSigFromHref(href);
        if (t) push(t);
      }
      if (out.length) break;
    }
  } catch (err) {
    // ignore
  }

  // 0) DOM attribute (most reliable when Gmail wraps/trims visible long strings).
  try {
    const scopes = Array.from(document.querySelectorAll("div.a3s"));
    for (let i = scopes.length - 1; i >= 0; i--) {
      const el = scopes[i].querySelector("[data-ns-signature]");
      if (!el) continue;
      push(el.getAttribute("data-ns-signature") || "");
      break;
    }
    if (!out.length) {
      const el = document.querySelector("[data-ns-signature]");
      if (el) push(el.getAttribute("data-ns-signature") || "");
    }
  } catch (err) {
    // ignore
  }

  // 1) Regex scan for signature tokens.
  //
  // Our signature tokens are always: v1|v1c . payload_b64url . sig_b64url
  // where the signature is HMAC-SHA256 -> 32 bytes -> 43 base64url chars (no padding).
  //
  // This fixed-length tail makes extraction robust even when Gmail inserts line breaks or
  // when multiple tokens appear adjacent in the rendered DOM.
  const scan = (text) => {
    const norm = normalizeToken(text);
    const re = /(v1c|v1)\.[A-Za-z0-9_-]+?\.[A-Za-z0-9_-]{43}/g;
    let m;
    while ((m = re.exec(norm))) {
      push(m[0]);
      if (out.length >= 6) break;
    }
  };
  scan(raw);
  if (html) scan(html.replace(/<[^>]+>/g, " "));

  // 2) Best-effort marker-based parser (useful when tokens are extremely short / malformed).
  push(extractSignatureToken(raw, html));

  // 3) data-ns-signature attribute (may be present when text is modified).
  if (html) {
    const m = html.match(/data-ns-signature=["']([^"']+)["']/);
    if (m) push(m[1]);
  }

  return out;
}

function extractStampFromDom() {
  try {
    const bodies = Array.from(document.querySelectorAll("div.a3s"));
    for (let i = bodies.length - 1; i >= 0; i--) {
      const el = bodies[i].querySelector("[data-provenance]");
      if (!el) continue;
      const status = el.getAttribute("data-provenance") || "";
      const reason = el.getAttribute("data-provenance-reason") || "";
      const attachments = el.getAttribute("data-provenance-attachments") || "";
      const attachmentsB64 = (el.getAttribute("data-provenance-attachments-b64") || "").replace(/\s+/g, "");
      const text = (el.textContent || "").trim();
      return { status, reason, attachments, attachmentsB64, text };
    }

    const el = document.querySelector("[data-provenance]");
    if (!el) return null;
    const status = el.getAttribute("data-provenance") || "";
    const reason = el.getAttribute("data-provenance-reason") || "";
    const attachments = el.getAttribute("data-provenance-attachments") || "";
    const attachmentsB64 = (el.getAttribute("data-provenance-attachments-b64") || "").replace(/\s+/g, "");
    const text = (el.textContent || "").trim();
    return { status, reason, attachments, attachmentsB64, text };
  } catch (err) {
    return null;
  }
}

function findComposeBody() {
  const active = document.activeElement;
  if (active && active.getAttribute && active.getAttribute("aria-label") === "Message Body") {
    return active;
  }
  const nodes = Array.from(document.querySelectorAll('[aria-label="Message Body"]'));
  return nodes[nodes.length - 1] || null;
}

async function verifyAttachments(settings, attachmentsHeader) {
  if (!attachmentsHeader) return null;
  try {
    let headerValue = attachmentsHeader;
    if (attachmentsHeader.startsWith("NS-ATTACHMENTS:")) {
      headerValue = attachmentsHeader.slice("NS-ATTACHMENTS:".length);
    }
    if (/^[A-Za-z0-9_=-]+$/.test(headerValue) && headerValue.length > 16) {
      try {
        const norm = headerValue.replace(/-/g, "+").replace(/_/g, "/");
        const pad = (4 - (norm.length % 4)) % 4;
        headerValue = atob(norm + "=".repeat(pad));
      } catch (err) {
        console.warn("[Nicrypt-Stego] Attachment header decode failed", err);
      }
    }
    const response = await chrome.runtime.sendMessage({
      type: "ns-verify",
      url: `${settings.baseUrl}/provenance/verify_attachment_headers`,
      headers: {
        Authorization: `Bearer ${settings.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ headers: { "X-Provenance-Attachment": headerValue } }),
    });
    if (!response || !response.ok) return null;
    return response.data || null;
  } catch (err) {
    console.warn("[Nicrypt-Stego] Attachment verify failed", err);
    return null;
  }
}

async function verifyAttachmentsB64(settings, attachmentsB64) {
  if (!attachmentsB64) return null;
  try {
    const token = String(attachmentsB64)
      .replace(/\s+/g, "")
      // Standard base64 may include '+' and '/'.
      .replace(/[^A-Za-z0-9+/=_-]/g, "");
    const response = await chrome.runtime.sendMessage({
      type: "ns-verify",
      url: `${settings.baseUrl}/provenance/verify_attachment_headers`,
      headers: {
        Authorization: `Bearer ${settings.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ headers: { "X-Provenance-Attachment-B64": token } }),
    });
    if (!response || !response.ok) return null;
    return response.data || null;
  } catch (err) {
    console.warn("[Nicrypt-Stego] Attachment-B64 verify failed", err);
    return null;
  }
}

function summarizeAttachmentResults(results) {
  if (!Array.isArray(results) || results.length === 0) return "";
  const total = results.length;
  const verified = results.filter((entry) => entry.verified).length;
  const failed = results.filter((entry) => !entry.verified).map((entry) => entry.filename).filter(Boolean);
  let summary = `Attachments: ${verified}/${total} verified`;
  if (failed.length) {
    const preview = failed.slice(0, 3).join(", ");
    summary += ` (failed: ${preview}${failed.length > 3 ? "…" : ""})`;
  }
  return summary;
}

async function verifyMessage() {
  const settings = await getSettings();
  if (!settings.token) {
    setPanel("Token missing", "Set a JWT in extension options.");
    setBadge("Token missing", "unverified");
    return;
  }
  // Never use selection for verification. It causes partial-token parsing and false negatives.
  const extracted = extractEmailBody({ allowSelection: false });
  let parsed = extractProvenanceBlock(extracted.text, extracted.html);
  let signatureToken = extractSignatureToken(extracted.text, extracted.html);
  let signatureCandidates = collectSignatureCandidates(extracted.text, extracted.html);
  try {
    const preview = (t) => (!t ? "" : t.length <= 64 ? t : `${t.slice(0, 28)}…${t.slice(-16)}`);
    console.warn("[Nicrypt-Stego] verify extracted", {
      selectionUsed: !!extracted.selectionUsed,
      sig: preview(signatureToken),
      sigLen: signatureToken ? signatureToken.length : 0,
      candidates: signatureCandidates.length,
      candLens: signatureCandidates.slice(0, 5).map((t) => t.length),
    });
  } catch (err) {
    // ignore
  }
  let stegoText = parsed.text;
  let bitsPerToken = parsed.bpt || settings.bitsPerToken;
  const rawHint = `${extracted.text || ""}\n${extracted.html || ""}`;
  const hasMarkerHints =
    rawHint.includes("NS-SIG:") ||
    rawHint.includes("NS-SIGNATURE:") ||
    rawHint.includes("NS-SIG-LINK:") ||
    rawHint.includes("ns_sig=") ||
    rawHint.includes("NS-ATTB64:") ||
    rawHint.includes("NS-ATTACHMENTS:") ||
    rawHint.includes("[Provenance:");
  const hasSigLinkMarker = rawHint.includes("NS-SIG-LINK:") || rawHint.includes("ns_sig=");

  // DOM fallback: if we missed the stamp in extracted content, pull it directly from the provenance element.
  const hasAnyMarkerInitial =
    !!signatureToken ||
    !!parsed.status ||
    !!parsed.cipher ||
    !!parsed.attachmentsB64 ||
    !!parsed.attachments ||
    !!parsed.found;
  if (!hasAnyMarkerInitial) {
    const dom = extractStampFromDom();
    if (dom && (dom.status || dom.reason || dom.attachments || dom.attachmentsB64)) {
      parsed = {
        ...parsed,
        status: dom.status,
        reason: dom.reason,
        attachments: dom.attachments,
        attachmentsB64: dom.attachmentsB64 || parsed.attachmentsB64,
      };
      if (!signatureToken) signatureToken = extractSignatureToken(dom.text, extracted.html);
    }
  }

  // If NS-SIG-LINK exists anywhere in the thread, extract it directly from message bodies as a fallback.
  if (hasSigLinkMarker && (!signatureToken || !/^(v1c|v1)\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43}$/.test(signatureToken))) {
    try {
      const bodies = Array.from(document.querySelectorAll("div.a3s"));
      const allText = bodies.map((n) => (n.innerText || "")).join("\n\n");
      const m = allText.match(/ns_sig=((v1c|v1)\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43})/i);
      if (m && m[1]) signatureToken = m[1];
    } catch (err) {
      // ignore
    }
  }

  // Gmail workflow: when NS-SIG-LINK is present we want fully deterministic behavior.
  // Do not attempt heuristic candidate scanning which is vulnerable to Gmail DOM/quoting corruption.
  if (hasSigLinkMarker) signatureCandidates = [];

  // Fallback: Gmail's DOM changes often (clipping, trimmed content, etc). If we didn't find any markers
  // in the extracted body, search the whole document for markers.
  const hasAnyMarker =
    !!signatureToken ||
    !!parsed.status ||
    !!parsed.cipher ||
    !!parsed.attachmentsB64 ||
    !!parsed.attachments ||
    !!parsed.found;
  if (!hasAnyMarker) {
    try {
      // Avoid scanning the entire document (Gmail UI text can contaminate tokens).
      // Instead, scan only message bodies.
      const bodies = Array.from(document.querySelectorAll("div.a3s"));
      const globalText = bodies
        .map((n) => (n.innerText || "").trim())
        .filter(Boolean)
        .join("\n\n");
      const globalHtml = bodies.map((n) => n.innerHTML || "").filter(Boolean).join("\n\n");
      const gParsed = extractProvenanceBlock(globalText, globalHtml);
      const gSig = extractSignatureToken(globalText, globalHtml);
      const gHas =
        !!gSig ||
        !!gParsed.status ||
        !!gParsed.cipher ||
        !!gParsed.attachmentsB64 ||
        !!gParsed.attachments ||
        !!gParsed.found;
      if (gHas) {
        console.warn("[Nicrypt-Stego] Falling back to global marker search");
        parsed = gParsed;
        signatureToken = gSig;
        signatureCandidates = collectSignatureCandidates(globalText, globalHtml);
        stegoText = gParsed.text;
        bitsPerToken = gParsed.bpt || settings.bitsPerToken;
      }
    } catch (err) {
      console.warn("[Nicrypt-Stego] Global marker search failed", err);
    }
  }
  if (!stegoText) {
    setPanel("No message body found", "Open an email and try again.");
    setBadge("No body", "unverified");
    return;
  }
  let signatureNote = "";

  // Fast path: if we have a deterministic token (e.g. from NS-SIG-LINK), verify that exact token first.
  // This avoids Gmail/UI contamination from heuristic candidate collection.
  const looksLikeSigToken = (t) => /^(v1c|v1)\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{43}$/.test(t || "");
  if (hasSigLinkMarker && (!signatureToken || !looksLikeSigToken(signatureToken))) {
    setPanel("Unverified sender", "Signature: could not parse NS-SIG-LINK token", false);
    setBadge("Unverified", "unverified");
    return;
  }
  if (signatureToken && looksLikeSigToken(signatureToken)) {
    try {
      const pv = signatureToken.length <= 60 ? signatureToken : `${signatureToken.slice(0, 28)}…${signatureToken.slice(-16)}`;
      const response = await chrome.runtime.sendMessage({
        type: "ns-verify",
        url: `${settings.baseUrl}/signature/verify`,
        headers: {
          Authorization: `Bearer ${settings.token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ token: signatureToken }),
      });
      if (!response) {
        signatureNote = `Signature: no response (token=${pv})`;
        setPanel("Unverified sender", signatureNote, false);
        setBadge("Unverified", "unverified");
        return;
      } else if (!response.ok) {
        const message = response.data?.error?.message || response.error || `HTTP ${response.status || "?"}`;
        signatureNote = `Signature: error (${message}) (token=${pv})`;
        setPanel("Unverified sender", signatureNote, false);
        setBadge("Unverified", "unverified");
        return;
      } else if (response.data?.verified) {
        const payload = response.data.payload || {};
        const metaLines = [
          payload.sender ? `Sender: ${payload.sender}` : "",
          payload.timestamp ? `Timestamp: ${payload.timestamp}` : "",
          payload.note ? `Note: ${payload.note}` : "",
          payload.org_id ? `Org: ${payload.org_id}` : "",
        ].filter(Boolean);
        let detail = metaLines.join("\n");
        if (parsed.attachmentsB64 || parsed.attachments) {
          const attachmentResp = parsed.attachmentsB64
            ? await verifyAttachmentsB64(settings, parsed.attachmentsB64)
            : await verifyAttachments(settings, parsed.attachments);
          const attachmentSummary = summarizeAttachmentResults(attachmentResp?.results);
          if (attachmentSummary) detail = detail ? `${detail}\n${attachmentSummary}` : attachmentSummary;
        }
        setPanel("Verified sender", detail, true);
        setBadge("Verified", "verified");
        return;
      } else {
        // If we got a non-verified response for a deterministic token, stop here and show details.
        // Falling back to heuristics makes Gmail behave non-deterministically.
        const reason = response?.data?.error?.message || "";
        const raw = (response?.text || "").trim();
        const rawPreview = raw ? (raw.length > 160 ? `${raw.slice(0, 160)}…` : raw) : "";
        signatureNote = `Signature: invalid (token=${pv})${reason ? ` (${reason})` : ""}${
          rawPreview ? `\nAPI: ${rawPreview}` : ""
        }`;
        setPanel("Unverified sender", signatureNote, false);
        setBadge("Unverified", "unverified");
        return;
      }
    } catch (err) {
      const pv = signatureToken.length <= 60 ? signatureToken : `${signatureToken.slice(0, 28)}…${signatureToken.slice(-16)}`;
      signatureNote = `Signature: error (${String(err)}) (token=${pv})`;
      setPanel("Unverified sender", signatureNote, false);
      setBadge("Unverified", "unverified");
      return;
    }
  }

  if (signatureCandidates.length) {
    try {
      let fatalError = false;
      const tried = new Set();
      const tryCandidates = async (cands) => {
        for (let i = 0; i < cands.length; i++) {
          const candidate = cands[i];
          if (!candidate) continue;
          if (tried.has(candidate)) continue;
          tried.add(candidate);
          const response = await chrome.runtime.sendMessage({
            type: "ns-verify",
            url: `${settings.baseUrl}/signature/verify`,
            headers: {
              Authorization: `Bearer ${settings.token}`,
              "Content-Type": "application/json",
            },
            body: JSON.stringify({ token: candidate }),
          });
          if (!response) {
            signatureNote = "Signature: no response";
            continue;
          }
          if (!response.ok) {
            const message = response.data?.error?.message || response.error || `HTTP ${response.status || "?"}`;
            signatureNote = `Signature: error (${message})`;
            // Auth/config errors won't change per-candidate.
            fatalError = true;
            return false;
          }
          if (response.data?.verified) {
            signatureToken = candidate;
            const payload = response.data.payload || {};
            const metaLines = [
              payload.sender ? `Sender: ${payload.sender}` : "",
              payload.timestamp ? `Timestamp: ${payload.timestamp}` : "",
              payload.note ? `Note: ${payload.note}` : "",
              payload.org_id ? `Org: ${payload.org_id}` : "",
            ].filter(Boolean);
            let detail = metaLines.join("\n");
            if (parsed.attachmentsB64 || parsed.attachments) {
              const attachmentResp = parsed.attachmentsB64
                ? await verifyAttachmentsB64(settings, parsed.attachmentsB64)
                : await verifyAttachments(settings, parsed.attachments);
              const attachmentSummary = summarizeAttachmentResults(attachmentResp?.results);
              if (attachmentSummary) detail = detail ? `${detail}\n${attachmentSummary}` : attachmentSummary;
            }
            setPanel("Verified sender", detail, true);
            setBadge("Verified", "verified");
            return true;
          }
          signatureNote = "Signature: invalid";
        }
        return false;
      };

      if (await tryCandidates(signatureCandidates)) return;

      // Second pass: if Gmail clipped/trimmed the message, the rendered body may contain a truncated token.
      // Re-scan the whole document for a complete candidate and try again.
      if (!fatalError && signatureNote === "Signature: invalid") {
        try {
          // Avoid scanning the entire document (Gmail UI can introduce garbage candidates).
          const bodies = Array.from(document.querySelectorAll("div.a3s"));
          const globalText = bodies
            .map((n) => (n.innerText || "").trim())
            .filter(Boolean)
            .join("\n\n");
          const globalHtml = bodies.map((n) => n.innerHTML || "").filter(Boolean).join("\n\n");
          const more = collectSignatureCandidates(globalText, globalHtml);
          if (more.length) {
            console.warn("[Nicrypt-Stego] Retrying signature verify with global candidates");
            if (await tryCandidates(more)) return;
            // Update for better debug output below.
            signatureCandidates = Array.from(new Set([...signatureCandidates, ...more]));
          }
        } catch (err) {
          console.warn("[Nicrypt-Stego] Global signature candidate scan failed", err);
        }
      }
      if (signatureNote === "Signature: invalid") {
        const preview = (t) => {
          if (!t) return "";
          if (t.length <= 60) return t;
          return `${t.slice(0, 28)}…${t.slice(-16)}`;
        };
        const first = signatureCandidates[0] || "";
        const debug = first ? ` (candidates=${signatureCandidates.length}, len=${first.length})` : "";
        const lines = signatureCandidates
          .slice(0, 3)
          .map((t, idx) => `sig${idx + 1}: ${preview(t)} (len=${t.length})`)
          .join("\n");
        signatureNote = `Signature: invalid${debug}${lines ? `\n${lines}` : ""}`;
      }
    } catch (err) {
      signatureNote = `Signature: error (${String(err)})`;
    }
  }

  if (parsed.status) {
    const label = parsed.status === "verified" ? "Verified" : "Unverified";
    let detail = parsed.reason ? `Reason: ${parsed.reason}` : "";
    if (signatureNote) detail = detail ? `${detail}\n${signatureNote}` : signatureNote;
    let badgeState = parsed.status === "verified" ? "verified" : "unverified";
    let badgeLabel = label;
    if (parsed.attachmentsB64 || parsed.attachments) {
      const attachmentResp = parsed.attachmentsB64
        ? await verifyAttachmentsB64(settings, parsed.attachmentsB64)
        : await verifyAttachments(settings, parsed.attachments);
      const attachmentSummary = summarizeAttachmentResults(attachmentResp?.results);
      if (attachmentSummary) {
        detail = detail ? `${detail}\n${attachmentSummary}` : attachmentSummary;
      }
      if (parsed.status === "verified" && attachmentResp?.results?.some((entry) => !entry.verified)) {
        badgeState = "partial";
        badgeLabel = "Partial";
      }
    }
    setPanel(`${label} sender`, detail, parsed.status === "verified");
    setBadge(badgeLabel, badgeState);
    return;
  }

  if (!parsed.found && !parsed.cipher) {
    // If we found a signature marker but couldn't validate it, don't pretend there were no markers.
    if (signatureToken || signatureCandidates.length || signatureNote) {
      let detail = signatureNote || "Signature: invalid";
      if (parsed.attachmentsB64 || parsed.attachments) {
        const attachmentResp = parsed.attachmentsB64
          ? await verifyAttachmentsB64(settings, parsed.attachmentsB64)
          : await verifyAttachments(settings, parsed.attachments);
        const attachmentSummary = summarizeAttachmentResults(attachmentResp?.results);
        if (attachmentSummary) detail = detail ? `${detail}\n${attachmentSummary}` : attachmentSummary;
      }
      setPanel("Unverified sender", detail, false);
      setBadge("Unverified", "unverified");
      return;
    }
    if (parsed.attachmentsB64 || parsed.attachments) {
      const attachmentResp = parsed.attachmentsB64
        ? await verifyAttachmentsB64(settings, parsed.attachmentsB64)
        : await verifyAttachments(settings, parsed.attachments);
      const attachmentSummary = summarizeAttachmentResults(attachmentResp?.results);
      if (attachmentSummary) {
        setPanel("Attachments verified", attachmentSummary, true);
        setBadge("Partial", "partial");
        return;
      }
    }
    if (hasMarkerHints) {
      setPanel(
        "Markers detected",
        "Provenance markers are present, but the extension could not parse them (message may be clipped or tokens truncated)."
      );
      setBadge("Unverified", "unverified");
      return;
    }
    setPanel("No provenance markers", "Embedded block not detected.");
    setBadge("Unverified", "unverified");
    return;
  }

  setPanel("Verifying...", "Contacting local API...", true);
  setBadge("Verifying...");

  try {
    const payload = parsed.cipher
      ? {
          ciphertext: parsed.cipher,
          model_name: settings.modelName,
          bits_per_token: bitsPerToken,
        }
      : {
          stego_text: stegoText,
          model_name: settings.modelName,
          bits_per_token: bitsPerToken,
        };

    const response = await chrome.runtime.sendMessage({
      type: "ns-verify",
      url: `${settings.baseUrl}/provenance/verify`,
      headers: {
        Authorization: `Bearer ${settings.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    });

    if (!response) {
      setPanel("Verify failed", "No response from extension service worker.");
      setBadge("Unverified", "unverified");
      return;
    }

    if (!response.ok) {
      const message = response.data?.error?.message || response.error || "Unknown error";
      setPanel("Verify failed", message);
      setBadge("Unverified", "unverified");
      return;
    }

    const data = response.data || {};
    if (!data.verified) {
      setPanel("Not verified", "No provenance detected.");
      setBadge("Unverified", "unverified");
      return;
    }

    const decryptResp = parsed.cipher
      ? await chrome.runtime.sendMessage({
          type: "ns-verify",
          url: `${settings.baseUrl}/crypto/decrypt`,
          headers: {
            Authorization: `Bearer ${settings.token}`,
            "Content-Type": "application/json",
          },
          body: JSON.stringify({ ciphertext: parsed.cipher }),
        })
      : null;

    const secretValue = decryptResp?.data?.secret || data.secret || "";
    const parts = secretValue.split("|");
    const email = parts[0] || "";
    const date = parts[1] || "";
    const label = parts.slice(2).join("|");
    const metaLines = [
      email ? `Sender: ${email}` : "",
      date ? `Date: ${date}` : "",
      label ? `Label: ${label}` : "",
      data.model_hash ? `Model Hash: ${data.model_hash}` : "",
      parsed.ts ? `Timestamp: ${parsed.ts}` : "",
    ].filter(Boolean);
    setPanel("Verified sender", metaLines.join("\n"), true);
    setBadge("Verified", "verified");
  } catch (err) {
    setPanel("Verify error", String(err));
    setBadge("Unverified", "unverified");
  }
}

function findSenderName() {
  const fromInput = document.querySelector('input[name="from"]');
  if (fromInput && fromInput.value) return fromInput.value;
  const sender = document.querySelector(".gD, .go, .g2");
  if (sender) return sender.textContent.trim();
  return "";
}

function insertAfterSignature(bodyNode, formatted) {
  const text = bodyNode.innerText || "";
  if (text.includes("NS-SIGNATURE:")) return;
  if (bodyNode.isContentEditable) {
    bodyNode.focus();
    const insertText = `\n${formatted.trim()}\n`;
    if (document.queryCommandSupported && document.queryCommandSupported("insertText")) {
      const ok = document.execCommand("insertText", false, insertText);
      if (ok) return;
    }
    bodyNode.appendChild(document.createTextNode(insertText));
  }
}

function findSendButton() {
  const buttons = Array.from(document.querySelectorAll('div[role="button"]'));
  return buttons.find((btn) => btn.innerText && btn.innerText.trim() === "Send") || null;
}

function shouldAutoSign() {
  return new Promise((resolve) => {
    chrome.storage.sync.get({ autoSign: true }, (items) => resolve(!!items.autoSign));
  });
}

async function embedDraft() {
  const settings = await getSettings();
  if (!settings.token) {
    setPanel("Token missing", "Set a JWT in extension options.");
    setBadge("Token missing", "unverified");
    return;
  }

  const bodyNode = findComposeBody();
  if (!bodyNode) {
    setPanel("Compose not found", "Open a Gmail compose window.");
    setBadge("No compose", "unverified");
    return;
  }

  if (settings.signatureEmbed) {
    const ok = await signVisible(bodyNode, settings);
    if (ok) {
      setPanel("Signed", "Visible signature added.", true);
      setBadge("Embedded");
    }
    return;
  }

  const coverPrompt = (bodyNode.innerText || "").trim();
  const secret = window.prompt("Enter provenance secret (stored in message):");
  if (!secret) {
    setPanel("Cancelled", "No secret provided.");
    setBadge("Cancelled", "unverified");
    return;
  }

  setPanel("Embedding...", "Generating stego text...", true);
  setBadge("Embedding...");

  try {
    const response = await chrome.runtime.sendMessage({
      type: "ns-embed",
      url: `${settings.baseUrl}/crypto/encrypt`,
      headers: {
        Authorization: `Bearer ${settings.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ plaintext: secret }),
    });

    if (!response) {
      setPanel("Embed failed", "No response from extension service worker.");
      setBadge("Unverified", "unverified");
      return;
    }

    if (!response.ok) {
      const message = response.data?.error?.message || response.error || "Unknown error";
      setPanel("Embed failed", message);
      setBadge("Unverified", "unverified");
      return;
    }

    const data = response.data || {};
    if (!data.ciphertext) {
      setPanel("Embed failed", "No ciphertext in response.");
      setBadge("Unverified", "unverified");
      return;
    }
    const markerLines = [
      "NS-PROVENANCE-START",
      `NS-CIPHERTEXT:${data.ciphertext}`,
      `NS-TIMESTAMP:${new Date().toISOString()}`,
      "NS-PROVENANCE-END",
    ];
    const span = document.createElement("span");
    span.style.display = "none";
    span.textContent = "\n" + markerLines.join("\n") + "\n";
    if (bodyNode.isContentEditable) {
      const comment = `<!-- ${markerLines.join(" ")} -->`;
      if (document.queryCommandSupported && document.queryCommandSupported("insertHTML")) {
        document.execCommand("insertHTML", false, comment);
      } else {
        bodyNode.insertAdjacentHTML("beforeend", comment);
      }
    } else {
      setPanel("Plain-text compose", "Hidden provenance not supported in plain-text mode.");
      setBadge("Unverified", "unverified");
      return;
    }
    setLastCiphertext(data.ciphertext, 4);
    setPanel("Embedded", "Hidden provenance marker added.", true);
    setBadge("Embedded");
  } catch (err) {
    setPanel("Embed error", String(err));
    setBadge("Unverified", "unverified");
  }
}

async function signVisible(bodyNode, settings) {
  setPanel("Signing...", "Generating signature token...", true);
  setBadge("Signing...");
  try {
    const senderName = settings.senderOverride || findSenderName() || "Unknown sender";
    const note = settings.signatureNote || "Best regards";
    const tokenResp = await chrome.runtime.sendMessage({
      type: "ns-embed",
      url: `${settings.baseUrl}/signature/token/compact`,
      headers: {
        Authorization: `Bearer ${settings.token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ sender: senderName, note }),
    });
    if (!tokenResp || !tokenResp.ok) {
      const message = tokenResp?.data?.error?.message || tokenResp?.error || "Unknown error";
      setPanel("Sign failed", message);
      setBadge("Unverified", "unverified");
      return false;
    }
    const formatted = tokenResp.data?.formatted || "";
    if (!formatted) {
      setPanel("Sign failed", "No formatted token returned.");
      setBadge("Unverified", "unverified");
      setComposeStatus("Sign failed", "unverified");
      return false;
    }
    insertAfterSignature(bodyNode, formatted);
    setComposeStatus("Signed ✓", "verified");
    return true;
  } catch (err) {
    setPanel("Sign error", String(err));
    setBadge("Unverified", "unverified");
    setComposeStatus("Sign error", "unverified");
    return false;
  }
}

async function ensureUi() {
  const settings = await getSettings();
  const embedButton = document.getElementById(EMBED_ID);
  const compose = findComposeBody();
  if ((settings.enableLegacyEmbed || settings.signatureEmbed) && compose) {
    if (!embedButton) {
      const button = document.createElement("button");
      button.id = EMBED_ID;
      button.className = "ns-embed-button";
      button.textContent = settings.signatureEmbed ? "Sign Draft" : "Embed Draft";
      button.addEventListener("click", (event) => {
        event.preventDefault();
        event.stopPropagation();
        console.log("[Nicrypt-Stego] Embed Draft clicked");
        embedDraft();
      });
      document.body.appendChild(button);
    } else {
      embedButton.textContent = settings.signatureEmbed ? "Sign Draft" : "Embed Draft";
    }
  } else if (embedButton) {
    embedButton.remove();
  }

  if (!document.getElementById(PANEL_ID)) {
    const panel = document.createElement("div");
    panel.id = PANEL_ID;
    panel.className = "ns-verify-panel";
    panel.dataset.nsBuild = NS_BUILD_ID;
    panel.innerHTML = `
      <div class="ns-verify-status">Ready</div>
      <div class="ns-verify-detail ns-verify-muted">Open an email, then click verify.</div>
      <button class="ns-toggle-panel" id="ns-toggle-panel" type="button">Obscure</button>
    `;
    document.body.appendChild(panel);
    const toggle = panel.querySelector("#ns-toggle-panel");
    if (toggle) {
      toggle.addEventListener("click", (event) => {
        event.preventDefault();
        hidePanel();
      });
    }
  }

  let badge = document.getElementById(BADGE_ID);
  if (!badge) {
    badge = document.createElement("span");
    badge.id = BADGE_ID;
    badge.className = "ns-verify-badge";
    badge.textContent = "Verify Sender";
    badge.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();
      const panel = document.getElementById(PANEL_ID);
      if (panel && panel.classList.contains("visible")) {
        hidePanel();
        return;
      }
      if (showLastPanel()) return;
      verifyMessage();
    });
  }
  const sender = document.querySelector(".gD, .go, .g2");
  if (sender && sender.parentElement && badge.parentElement !== sender.parentElement) {
    sender.parentElement.appendChild(badge);
    badge.classList.remove("floating");
  } else if (!sender && !badge.parentElement) {
    document.body.appendChild(badge);
    badge.classList.add("floating");
  }

  const messageBody = document.querySelector("div.a3s");
  if (compose && !messageBody) {
    badge.style.display = "none";
  } else {
    badge.style.display = "";
    if (lastPanelState) {
      const panel = document.getElementById(PANEL_ID);
      badge.classList.remove("verified", "unverified", "partial");
      badge.textContent = panel && panel.classList.contains("visible") ? "Obscure" : "Trace";
    } else {
      badge.classList.remove("verified", "unverified", "partial");
      badge.textContent = "Verify Sender";
    }
  }
  let composeStatus = document.getElementById(COMPOSE_STATUS_ID);
  if (compose) {
    if (!composeStatus) {
      composeStatus = document.createElement("span");
      composeStatus.id = COMPOSE_STATUS_ID;
      composeStatus.className = "ns-compose-status";
      composeStatus.textContent = "Compose ready";
      document.body.appendChild(composeStatus);
    }
  } else if (composeStatus) {
    composeStatus.remove();
  }
}

function hidePanel() {
  const panel = document.getElementById(PANEL_ID);
  if (panel) {
    panel.classList.remove("visible");
  }
  const badge = document.getElementById(BADGE_ID);
  if (badge) {
    badge.classList.remove("verified", "unverified", "partial");
    badge.textContent = lastPanelState ? "Trace" : "Verify Sender";
  }
}

function observe() {
  ensureUi();
  const observer = new MutationObserver(() => ensureUi());
  observer.observe(document.body, { childList: true, subtree: true });
  setInterval(updateBadgeFromStamp, 1500);

  let lastUrl = location.href;
  setInterval(() => {
    if (location.href !== lastUrl) {
      lastUrl = location.href;
      hidePanel();
      setBadge("Verify Sender");
    }
  }, 500);

  const originalPushState = history.pushState;
  history.pushState = function (...args) {
    originalPushState.apply(this, args);
    hidePanel();
    setBadge("Verify Sender");
  };
  window.addEventListener("popstate", () => {
    hidePanel();
    setBadge("Verify Sender");
  });
  window.addEventListener("hashchange", () => {
    hidePanel();
    setBadge("Verify Sender");
  });

  document.body.addEventListener("click", async (event) => {
    const target = event.target;
    if (!target) return;
    const button = target.closest && target.closest('div[role="button"]');
    if (!button) return;
    if (!button.innerText || button.innerText.trim() !== "Send") return;
    setBadge("Auto‑signing...");
    const autoSign = await shouldAutoSign();
    const settings = await getSettings();
    if (!autoSign || !settings.signatureEmbed) return;
    const bodyNode = findComposeBody();
    if (!bodyNode) {
      setBadge("Auto‑sign failed", "unverified");
      return;
    }
    if ((bodyNode.innerText || "").includes("NS-SIGNATURE:")) {
      setBadge("Already signed");
      return;
    }
    const ok = await signVisible(bodyNode, settings);
    setBadge(ok ? "Auto‑signed" : "Auto‑sign failed");
    setComposeStatus(ok ? "Signed ✓" : "Sign failed", ok ? "verified" : "unverified");
  });
}

observe();
