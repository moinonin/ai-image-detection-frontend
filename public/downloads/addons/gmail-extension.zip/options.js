const baseUrl = document.getElementById("baseUrl");
const token = document.getElementById("token");
const modelName = document.getElementById("modelName");
const bitsPerToken = document.getElementById("bitsPerToken");
const enableLegacyEmbed = document.getElementById("enableLegacyEmbed");
const signatureEmbed = document.getElementById("signatureEmbed");
const signatureNote = document.getElementById("signatureNote");
const senderOverride = document.getElementById("senderOverride");
const autoSign = document.getElementById("autoSign");
const status = document.getElementById("status");
const signaturePreview = document.getElementById("signaturePreview");
const previewButton = document.getElementById("previewSignature");

function load() {
  chrome.storage.sync.get(
    {
      baseUrl: "",
      token: "",
      modelName: "sshleifer/tiny-gpt2",
      bitsPerToken: 4,
      enableLegacyEmbed: false,
      signatureEmbed: true,
      signatureNote: "Best regards",
      senderOverride: "",
      autoSign: true,
    },
    (items) => {
      baseUrl.value = items.baseUrl;
      token.value = items.token;
      modelName.value = items.modelName;
      bitsPerToken.value = items.bitsPerToken;
      enableLegacyEmbed.checked = items.enableLegacyEmbed;
      signatureEmbed.checked = items.signatureEmbed;
      signatureNote.value = items.signatureNote;
      senderOverride.value = items.senderOverride;
      autoSign.checked = items.autoSign;
    }
  );
}

function save() {
  const url = baseUrl.value.trim();
  // Host permissions: for the Web Store build we request runtime permission for the configured API base.
  // In dev builds, the manifest may already include localhost permissions.
  if (url) {
    try {
      const u = new URL(url);
      const originPattern = `${u.origin}/*`;
      if (chrome?.permissions?.request) {
        chrome.permissions.request({ origins: [originPattern] }, () => {
          // Whether granted or denied, we still persist settings; verification will show an error if denied.
        });
      }
    } catch {
      // Ignore invalid URLs; save() will still store it and verification will error more clearly.
    }
  }

  chrome.storage.sync.set(
    {
      baseUrl: url,
      token: token.value.trim(),
      modelName: modelName.value.trim(),
      bitsPerToken: Number(bitsPerToken.value || 4),
      enableLegacyEmbed: !!enableLegacyEmbed.checked,
      signatureEmbed: !!signatureEmbed.checked,
      signatureNote: signatureNote.value.trim() || "Best regards",
      senderOverride: senderOverride.value.trim(),
      autoSign: !!autoSign.checked,
    },
    () => {
      status.textContent = "Saved.";
      setTimeout(() => (status.textContent = ""), 1500);
    }
  );
}

document.getElementById("save").addEventListener("click", save);
previewButton.addEventListener("click", () => {
  const note = signatureNote.value.trim() || "Best regards";
  const sender = senderOverride.value.trim() || "Sender Name";
  const payload = { sender, note };
  const base = baseUrl.value.trim();
  const jwt = token.value.trim();
  if (!jwt) {
    signaturePreview.textContent = `${note}\nNS-SIGNATURE: v1.<token>\n`;
    return;
  }
  if (!base) {
    signaturePreview.textContent = "Set Base URL first.";
    return;
  }
  signaturePreview.textContent = "Fetching token...";
  fetch(`${base}/signature/token`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${jwt}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify(payload),
  })
    .then((resp) => resp.json())
    .then((data) => {
      signaturePreview.textContent = `${note}\n${data.formatted || "NS-SIGNATURE: v1.<token>"}\n`;
    })
    .catch(() => {
      signaturePreview.textContent = `${note}\nNS-SIGNATURE: v1.<token>\n`;
    });
});
load();
