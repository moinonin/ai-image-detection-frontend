Outlook Add-in (PoC)

Overview
This add-in reads inbound internet headers and calls /v1/provenance/verify_headers.

Sideload (Outlook on the web)
1) Host the add-in files on a local server (e.g., http://localhost:3000/outlook-addin/).
2) Update manifest.xml SourceLocation to your URL.
3) In Outlook web: Settings -> Manage add-ins -> Upload custom add-in.

Local dev (quick)
- Serve the folder with any static server.
- Open taskpane.html to verify UI loads.

Quick test flow
1) Serve the add-in assets locally:
```
python -m http.server 3000
```

2) Update `manifest.xml` SourceLocation to:
```
http://localhost:3000/poc/outlook-addin/taskpane.html
```

3) Sideload in Outlook on the web:
Settings -> Manage add-ins -> Upload custom add-in

4) Open any message and click "Verify Message".
5) Set API Base + API Token in the add-in panel and click "Save Settings".

Notes
- Attachment verification uses `X-Provenance-Attachment` header if present.
- If message verified but some attachments fail, status shows "Partial".

Screenshot placeholders
- `docs/outlook_addin_taskpane.png`
- `docs/outlook_addin_verified.png`
