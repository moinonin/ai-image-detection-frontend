function parseHeaders(headersText) {
  const headers = {};
  let currentKey = null;
  const lines = (headersText || "").split("\r\n");
  lines.forEach((line) => {
    if (!line) return;
    if (/^\s/.test(line) && currentKey) {
      headers[currentKey] = `${headers[currentKey]} ${line.trim()}`;
      return;
    }
    const idx = line.indexOf(":");
    if (idx > 0) {
      const key = line.slice(0, idx);
      const value = line.slice(idx + 1).trim();
      if (key && value) {
        headers[key] = value;
        currentKey = key;
      }
    }
  });
  return headers;
}

function summarizeAttachments(results) {
  if (!Array.isArray(results) || results.length === 0) return "";
  const total = results.length;
  const verified = results.filter((entry) => entry.verified).length;
  const failed = results.filter((entry) => !entry.verified).map((entry) => entry.filename).filter(Boolean);
  let summary = `Attachments: ${verified}/${total} verified`;
  if (failed.length) {
    summary += ` (failed: ${failed.slice(0, 3).join(", ")}${failed.length > 3 ? "…" : ""})`;
  }
  return summary;
}

function setPill(statusEl, text, cls) {
  statusEl.textContent = text;
  statusEl.classList.remove("verified", "unverified", "partial");
  if (cls) statusEl.classList.add(cls);
}

function formatTimestamp(value) {
  if (!value) return "";
  const first = String(value).split(",")[0].trim();
  const d = new Date(first);
  if (!Number.isNaN(d.getTime())) return d.toISOString().slice(0, 16);
  const m = first.match(/\d{4}-\d{2}-\d{2}T\d{2}:\d{2}/);
  return m ? m[0] : first;
}

async function verifyHeaders() {
  const status = document.getElementById("status");
  const meta = document.getElementById("meta");
  setPill(status, "Verifying...", "");
  meta.textContent = "";

  const item = Office.context.mailbox.item;
  item.getAllInternetHeaders(async (result) => {
    if (result.status !== Office.AsyncResultStatus.Succeeded) {
      setPill(status, "🚨 ns-stego unverified", "unverified");
      return;
    }
    const headersText = result.value || "";
    const headers = parseHeaders(headersText);

    const apiBase = localStorage.getItem("apiBase") || "http://127.0.0.1:8125/v1";
    const token = localStorage.getItem("apiToken") || "";
    const resp = await fetch(`${apiBase}/provenance/verify_headers`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${token}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ headers }),
    });
    const data = await resp.json();
    if (!resp.ok) {
      setPill(status, "🚨 ns-stego unverified", "unverified");
      meta.textContent = data?.error?.message || "Unknown error";
      return;
    }
    const ok = !!data.verified;
    let badgeClass = ok ? "verified" : "unverified";
    let badgeText = ok ? "🔒 ns-stego verified" : "🚨 ns-stego unverified";
    const lines = [
      data.secret ? `Sender: ${data.secret}` : "",
      data.policy?.reason && !ok ? `Reason: ${data.policy.reason}` : "",
      data.timestamp ? `Timestamp: ${formatTimestamp(data.timestamp)}` : "",
    ].filter(Boolean);

    const attachmentHeader = headers["X-Provenance-Attachment"] || headers["x-provenance-attachment"];
    if (attachmentHeader) {
      const attachResp = await fetch(`${apiBase}/provenance/verify_attachment_headers`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${token}`,
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ headers: { "X-Provenance-Attachment": attachmentHeader } }),
      });
      const attachData = await attachResp.json();
      const summary = summarizeAttachments(attachData?.results);
      if (summary) lines.push(summary);
      if (data.verified && attachData?.results?.some((entry) => !entry.verified)) {
        badgeClass = "partial";
        badgeText = "ns-stego partial";
      }
    }

    setPill(status, badgeText, badgeClass);
    meta.textContent = lines.join("\n");
  });
}

function extractSignatureToken(text) {
  if (!text) return "";
  // Prefer NS-SIG-LINK (the current deterministic carrier).
  const m1 = text.match(/NS-SIG-LINK:\s*(?:ns_sig=)?((v1c|v1)\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{20,})/i);
  if (m1) return m1[1];
  const m2 = text.match(/ns_sig=((v1c|v1)\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{20,})/i);
  if (m2) return m2[1];
  // Legacy fallback.
  const m3 = text.match(/NS-SIGNATURE:\s*((v1c|v1)\.[A-Za-z0-9_-]+\.[A-Za-z0-9_-]{20,})/i);
  return m3 ? m3[1] : "";
}

async function verifySignatureToken(tokenValue) {
  const status = document.getElementById("status");
  const meta = document.getElementById("meta");
  const apiBase = localStorage.getItem("apiBase") || "http://127.0.0.1:8125/v1";
  const token = localStorage.getItem("apiToken") || "";
  const resp = await fetch(`${apiBase}/signature/verify`, {
    method: "POST",
    headers: {
      Authorization: `Bearer ${token}`,
      "Content-Type": "application/json",
    },
    body: JSON.stringify({ token: tokenValue }),
  });
  const data = await resp.json();
  if (!resp.ok) {
    setPill(status, "🚨 ns-stego unverified", "unverified");
    meta.textContent = data?.error?.message || "Unknown error";
    return false;
  }
  if (!data.verified) {
    setPill(status, "🚨 ns-stego unverified", "unverified");
    meta.textContent = "Invalid signature token";
    return false;
  }
  setPill(status, "🔒 ns-stego verified", "verified");
  const payload = data.payload || {};
  const lines = [
    payload.sender ? `Sender: ${payload.sender}` : "",
    payload.timestamp ? `Timestamp: ${formatTimestamp(payload.timestamp)}` : "",
    payload.note ? `Note: ${payload.note}` : "",
    payload.org_id ? `Org: ${payload.org_id}` : "",
  ].filter(Boolean);
  meta.textContent = lines.join("\n");
  return true;
}

async function verifyMessage() {
  const item = Office.context.mailbox.item;
  item.body.getAsync("text", async (result) => {
    if (result.status === Office.AsyncResultStatus.Succeeded) {
      const tokenValue = extractSignatureToken(result.value || "");
      if (tokenValue) {
        const ok = await verifySignatureToken(tokenValue);
        if (ok) return;
      }
    }
    verifyHeaders();
  });
}

function loadSettings() {
  const apiBase = localStorage.getItem("apiBase") || "http://127.0.0.1:8125/v1";
  const apiToken = localStorage.getItem("apiToken") || "";
  document.getElementById("apiBase").value = apiBase;
  document.getElementById("apiToken").value = apiToken;
}

function saveSettings() {
  const apiBase = document.getElementById("apiBase").value.trim();
  const apiToken = document.getElementById("apiToken").value.trim();
  if (apiBase) localStorage.setItem("apiBase", apiBase);
  if (apiToken) localStorage.setItem("apiToken", apiToken);
}

document.getElementById("verify").addEventListener("click", verifyMessage);
document.getElementById("save").addEventListener("click", saveSettings);
Office.onReady(() => {
  loadSettings();
  verifyMessage();
});
